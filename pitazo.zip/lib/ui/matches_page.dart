import 'dart:async';

import 'package:flutter/material.dart';

import '../config.dart';
import '../models/football_match.dart';
import '../services/api_client.dart';
import '../util/dates.dart';
import 'editorial_widgets.dart';
import 'match_tile.dart';
import 'theme.dart';

class MatchesPage extends StatefulWidget {
  const MatchesPage({super.key, this.client});

  /// Permite inyectar un cliente falso en pruebas.
  final ApiClient? client;

  @override
  State<MatchesPage> createState() => _MatchesPageState();
}

class _MatchesPageState extends State<MatchesPage> {
  late final ApiClient _api;
  late final DateTime _today;
  late DateTime _selected;
  late final List<DateTime> _days;
  Timer? _timer;

  List<FootballMatch>? _matches;
  Object? _error;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _api = widget.client ?? ApiClient();
    _today = dateOnly(DateTime.now());
    _selected = _today;
    // Tres días antes y tres después de hoy. Se construyen con DateTime(...)
    // y no sumando Duration, para no desplazarse con el cambio de hora.
    _days = List.generate(
      7,
      (i) => DateTime(_today.year, _today.month, _today.day + i - 3),
    );
    _load();
    _timer = Timer.periodic(AppConfig.refreshEvery, (_) {
      if (sameDay(_selected, _today)) _load(silent: true);
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _load({bool silent = false}) async {
    final day = _selected;
    if (!silent) {
      setState(() {
        _loading = true;
        _error = null;
      });
    }
    try {
      final result = await _api.fetchMatches(day);
      if (!mounted || !sameDay(day, _selected)) return;
      setState(() {
        _matches = result;
        _error = null;
        _loading = false;
      });
    } catch (e) {
      if (!mounted || !sameDay(day, _selected)) return;
      setState(() {
        _loading = false;
        // Un fallo en un refresco silencioso no borra lo que ya se ve.
        if (!silent || _matches == null) _error = e;
      });
    }
  }

  void _select(DateTime day) {
    if (sameDay(day, _selected)) return;
    setState(() {
      _selected = day;
      _matches = null;
    });
    _load();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      bottom: false,
      child: Column(
        children: [
          Masthead(today: _today),
          DateTabs(days: _days, selected: _selected, onSelected: _select),
          Expanded(child: _body()),
        ],
      ),
    );
  }

  Widget _body() {
    final matches = _matches;
    if (matches == null && _error == null) {
      return const Center(child: CircularProgressIndicator(color: Pal.accent));
    }
    if (matches == null) {
      return _ErrorView(onRetry: _load);
    }
    return RefreshIndicator(
      color: Pal.accent,
      onRefresh: () => _load(silent: true),
      child: ListView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.fromLTRB(20, 0, 20, 24),
        children: matches.isEmpty ? [const _EmptyView()] : _sections(matches),
      ),
    );
  }

  List<Widget> _sections(List<FootballMatch> matches) {
    final groups = <String, List<FootballMatch>>{};
    for (final m in matches) {
      groups.putIfAbsent(m.competitionCode, () => []).add(m);
    }
    final children = <Widget>[];
    for (final group in groups.values) {
      children.add(LeagueHeader(name: group.first.competitionName, area: group.first.area));
      for (var i = 0; i < group.length; i++) {
        children.add(MatchTile(match: group[i], showTopRule: i > 0));
      }
    }
    return children;
  }
}

class _EmptyView extends StatelessWidget {
  const _EmptyView();

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 48),
      child: Text(
        'No hay partidos este día en las competiciones disponibles.',
        textAlign: TextAlign.center,
        style: serif(18, color: Pal.muted),
      ),
    );
  }
}

class _ErrorView extends StatelessWidget {
  const _ErrorView({required this.onRetry});

  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'No se han podido cargar los partidos.',
              textAlign: TextAlign.center,
              style: serif(20),
            ),
            const SizedBox(height: 8),
            Text(
              'Comprueba tu conexión e inténtalo de nuevo.',
              textAlign: TextAlign.center,
              style: sans(14, color: Pal.muted),
            ),
            const SizedBox(height: 16),
            TextButton(
              onPressed: onRetry,
              style: TextButton.styleFrom(
                foregroundColor: Pal.accent,
                minimumSize: const Size(48, 48),
              ),
              child: Text(
                'REINTENTAR',
                style: sans(12, color: Pal.accent, weight: FontWeight.w700, letterSpacing: 1.2),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
