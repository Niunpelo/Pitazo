import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../models/football_match.dart';
import '../util/dates.dart';
import 'theme.dart';

/// Un partido: columna de estado a la izquierda y dos líneas con puntos guía.
class MatchTile extends StatelessWidget {
  const MatchTile({super.key, required this.match, required this.showTopRule});

  final FootballMatch match;
  final bool showTopRule;

  @override
  Widget build(BuildContext context) {
    final phase = match.phase;
    final live = match.isLive;
    final finished = phase == MatchPhase.finished;
    final h = match.homeGoals;
    final a = match.awayGoals;
    final hasScore = h != null && a != null && phase != MatchPhase.scheduled;

    Color nameColor(bool isHome) {
      if (!finished || h == null || a == null || h == a) return Pal.ink;
      final homeWins = h > a;
      return (isHome == homeWins) ? Pal.ink : Pal.muted;
    }

    Color goalColor(bool isHome) {
      if (live) return Pal.accent;
      if (!hasScore) return Pal.muted;
      return nameColor(isHome);
    }

    return Semantics(
      container: true,
      label: _semanticLabel(),
      child: Container(
        decoration: BoxDecoration(
          border: showTopRule ? const Border(top: BorderSide(color: Pal.rule)) : null,
        ),
        padding: const EdgeInsets.symmetric(vertical: 12),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(width: 52, child: _StatusColumn(match: match)),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                children: [
                  _TeamLine(
                    name: match.home.shortName,
                    goals: hasScore ? '$h' : '–',
                    nameColor: nameColor(true),
                    goalColor: goalColor(true),
                  ),
                  const SizedBox(height: 4),
                  _TeamLine(
                    name: match.away.shortName,
                    goals: hasScore ? '$a' : '–',
                    nameColor: nameColor(false),
                    goalColor: goalColor(false),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  String _semanticLabel() {
    final h = match.homeGoals;
    final a = match.awayGoals;
    final teams = '${match.home.shortName} contra ${match.away.shortName}';
    switch (match.phase) {
      case MatchPhase.scheduled:
        final time = DateFormat('HH:mm').format(match.kickoff.toLocal());
        return '$teams, a las $time';
      case MatchPhase.interrupted:
        return '$teams, ${match.interruptedLabel}';
      case MatchPhase.live:
      case MatchPhase.halfTime:
        return '$teams, en juego, ${h ?? 0} a ${a ?? 0}';
      case MatchPhase.finished:
        return '$teams, final, ${h ?? 0} a ${a ?? 0}';
    }
  }
}

class _StatusColumn extends StatelessWidget {
  const _StatusColumn({required this.match});

  final FootballMatch match;

  @override
  Widget build(BuildContext context) {
    switch (match.phase) {
      case MatchPhase.finished:
        return Padding(
          padding: const EdgeInsets.only(top: 3),
          child: Text('Final', style: sans(12, color: Pal.muted, style: FontStyle.italic)),
        );
      case MatchPhase.live:
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'EN JUEGO',
              style: sans(10, color: Pal.accent, weight: FontWeight.w700, letterSpacing: 0.8),
            ),
            if (match.minute != null)
              Text('${match.minute}\'', style: serif(18, color: Pal.accent)),
          ],
        );
      case MatchPhase.halfTime:
        return Text(
          'DESCANSO',
          style: sans(10, color: Pal.accent, weight: FontWeight.w700, letterSpacing: 0.8),
        );
      case MatchPhase.interrupted:
        return Padding(
          padding: const EdgeInsets.only(top: 3),
          child: Text(
            match.interruptedLabel,
            style: sans(11, color: Pal.muted, style: FontStyle.italic),
          ),
        );
      case MatchPhase.scheduled:
        final local = match.kickoff.toLocal();
        final dayLabel = sameDay(local, DateTime.now())
            ? 'Hoy'
            : DateFormat('d MMM', 'es').format(local);
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(dayLabel, style: sans(11, color: Pal.muted, style: FontStyle.italic)),
            Text(DateFormat('HH:mm').format(local), style: serif(18)),
          ],
        );
    }
  }
}

/// Nombre del equipo, puntos guía y marcador. Los puntos se dibujan debajo y
/// el nombre y el marcador los tapan con el color del papel.
class _TeamLine extends StatelessWidget {
  const _TeamLine({
    required this.name,
    required this.goals,
    required this.nameColor,
    required this.goalColor,
  });

  final String name;
  final String goals;
  final Color nameColor;
  final Color goalColor;

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        const Positioned(
          left: 0,
          right: 0,
          bottom: 6,
          height: 1,
          child: CustomPaint(painter: _DotsPainter(Pal.muted)),
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Flexible(
              child: Container(
                color: Pal.paper,
                padding: const EdgeInsets.only(right: 6),
                child: Text(
                  name,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: serif(19, color: nameColor),
                ),
              ),
            ),
            Container(
              color: Pal.paper,
              padding: const EdgeInsets.only(left: 6),
              child: Text(goals, style: serif(19, color: goalColor)),
            ),
          ],
        ),
      ],
    );
  }
}

class _DotsPainter extends CustomPainter {
  const _DotsPainter(this.color);

  final Color color;

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = color;
    for (double x = 0; x < size.width; x += 3.5) {
      canvas.drawCircle(Offset(x, size.height / 2), 0.7, paint);
    }
  }

  @override
  bool shouldRepaint(_DotsPainter oldDelegate) => oldDelegate.color != color;
}
