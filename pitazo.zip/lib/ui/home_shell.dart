import 'package:flutter/material.dart';

import 'editorial_widgets.dart';
import 'matches_page.dart';
import 'theme.dart';

/// Contenedor con las cuatro pestañas. Solo "Partidos" está implementada;
/// el resto son marcadores de posición hasta que se construyan.
class HomeShell extends StatefulWidget {
  const HomeShell({super.key});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _index = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: _index,
        children: const [
          MatchesPage(),
          _Soon(title: 'Tablas'),
          _Soon(title: 'Favoritos'),
          _Soon(title: 'Ajustes'),
        ],
      ),
      bottomNavigationBar: EditorialNav(
        index: _index,
        onChanged: (i) => setState(() => _index = i),
      ),
    );
  }
}

class _Soon extends StatelessWidget {
  const _Soon({required this.title});

  final String title;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(title, style: serif(32)),
            const SizedBox(height: 8),
            Text('Próximamente', style: sans(14, color: Pal.muted, style: FontStyle.italic)),
          ],
        ),
      ),
    );
  }
}
