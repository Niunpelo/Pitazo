import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../util/dates.dart';
import 'theme.dart';

/// Filete doble de periódico: línea gruesa, hueco y línea fina.
class DoubleRule extends StatelessWidget {
  const DoubleRule({super.key, this.thickness = 3});

  final double thickness;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(height: thickness, color: Pal.ink),
        const SizedBox(height: 3),
        Container(height: 1, color: Pal.ink),
      ],
    );
  }
}

/// Cabecera tipo portada: fecha, título y lema.
class Masthead extends StatelessWidget {
  const Masthead({super.key, required this.today});

  final DateTime today;

  @override
  Widget build(BuildContext context) {
    final dateLabel =
        DateFormat("EEEE, d 'de' MMMM 'de' yyyy", 'es').format(today).toUpperCase();
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 14, 20, 0),
      child: Column(
        children: [
          Align(
            alignment: Alignment.centerLeft,
            child: Text(
              dateLabel,
              style: sans(11, color: Pal.muted, weight: FontWeight.w500, letterSpacing: 1.2),
            ),
          ),
          Text(
            'Pitazo',
            style: serif(56, height: 1.1).copyWith(letterSpacing: -1),
          ),
          const SizedBox(height: 10),
          const DoubleRule(),
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 6),
            child: FittedBox(
              fit: BoxFit.scaleDown,
              child: Text(
                'RESULTADOS · CLASIFICACIONES · EN DIRECTO',
                style: sans(11, color: Pal.muted, weight: FontWeight.w500, letterSpacing: 2),
              ),
            ),
          ),
          Container(height: 1, color: Pal.ink),
        ],
      ),
    );
  }
}

/// Tira de días: la fecha seleccionada va en rojo y subrayada.
class DateTabs extends StatelessWidget {
  const DateTabs({
    super.key,
    required this.days,
    required this.selected,
    required this.onSelected,
  });

  final List<DateTime> days;
  final DateTime selected;
  final ValueChanged<DateTime> onSelected;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: Row(
        children: [
          for (final day in days)
            Expanded(
              child: _DayTab(
                day: day,
                selected: sameDay(day, selected),
                onTap: () => onSelected(day),
              ),
            ),
        ],
      ),
    );
  }
}

class _DayTab extends StatelessWidget {
  const _DayTab({required this.day, required this.selected, required this.onTap});

  final DateTime day;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final weekday = DateFormat('E', 'es').format(day).toUpperCase();
    return Semantics(
      button: true,
      selected: selected,
      label: DateFormat("EEEE d 'de' MMMM", 'es').format(day),
      child: InkWell(
        onTap: onTap,
        child: Container(
          constraints: const BoxConstraints(minHeight: 52),
          decoration: BoxDecoration(
            border: Border(
              bottom: BorderSide(
                color: selected ? Pal.accent : Colors.transparent,
                width: 3,
              ),
            ),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                weekday,
                style: sans(
                  11,
                  color: selected ? Pal.accent : Pal.muted,
                  weight: selected ? FontWeight.w700 : FontWeight.w500,
                  letterSpacing: 0.8,
                ),
              ),
              Text('${day.day}', style: serif(20, color: selected ? Pal.accent : Pal.ink)),
            ],
          ),
        ),
      ),
    );
  }
}

/// Título de sección de una liga, con filete grueso debajo.
class LeagueHeader extends StatelessWidget {
  const LeagueHeader({super.key, required this.name, this.area});

  final String name;
  final String? area;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(0, 14, 0, 6),
      decoration: const BoxDecoration(
        border: Border(bottom: BorderSide(color: Pal.ink, width: 2)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Expanded(child: Text(name, style: serif(22, height: 1.1))),
          if (area != null)
            Text(
              area!,
              style: sans(12, color: Pal.muted, style: FontStyle.italic),
            ),
        ],
      ),
    );
  }
}

/// Barra inferior solo de texto, con filete doble arriba.
class EditorialNav extends StatelessWidget {
  const EditorialNav({super.key, required this.index, required this.onChanged});

  static const labels = ['PARTIDOS', 'TABLAS', 'FAVORITOS', 'AJUSTES'];

  final int index;
  final ValueChanged<int> onChanged;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Pal.paper,
      child: SafeArea(
        top: false,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(height: 1, color: Pal.ink),
            const SizedBox(height: 1),
            Container(height: 1, color: Pal.ink),
            Row(
              children: [
                for (var i = 0; i < labels.length; i++)
                  Expanded(
                    child: Semantics(
                      button: true,
                      selected: i == index,
                      child: InkWell(
                        onTap: () => onChanged(i),
                        child: Container(
                          height: 56,
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                            border: Border(
                              bottom: BorderSide(
                                color: i == index ? Pal.accent : Colors.transparent,
                                width: 3,
                              ),
                            ),
                          ),
                          child: Text(
                            labels[i],
                            style: sans(
                              12,
                              color: i == index ? Pal.accent : Pal.muted,
                              weight: i == index ? FontWeight.w700 : FontWeight.w500,
                              letterSpacing: 1.2,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
