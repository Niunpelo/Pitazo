import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// Paleta "Editorial": papel crema, tinta casi negra y un rojo de acento.
class Pal {
  Pal._();

  static const paper = Color(0xFFF4EFE6);
  static const ink = Color(0xFF16130F);
  static const muted = Color(0xFF5E574C);
  static const rule = Color(0xFFC9C0AE);
  static const accent = Color(0xFFB3261E);
}

TextStyle serif(double size, {Color color = Pal.ink, double height = 1.15}) {
  return GoogleFonts.dmSerifDisplay(fontSize: size, color: color, height: height);
}

TextStyle sans(
  double size, {
  Color color = Pal.ink,
  FontWeight weight = FontWeight.w400,
  double letterSpacing = 0,
  FontStyle style = FontStyle.normal,
}) {
  return GoogleFonts.dmSans(
    fontSize: size,
    color: color,
    fontWeight: weight,
    letterSpacing: letterSpacing,
    fontStyle: style,
  );
}

ThemeData buildTheme() {
  final scheme = ColorScheme.fromSeed(seedColor: Pal.accent).copyWith(
    primary: Pal.accent,
    surface: Pal.paper,
    onSurface: Pal.ink,
  );
  final base = ThemeData(
    useMaterial3: true,
    colorScheme: scheme,
    scaffoldBackgroundColor: Pal.paper,
  );
  return base.copyWith(
    textTheme: GoogleFonts.dmSansTextTheme(base.textTheme).apply(
      bodyColor: Pal.ink,
      displayColor: Pal.ink,
    ),
  );
}
