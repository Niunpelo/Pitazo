import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';

import '../config.dart';
import '../models/football_match.dart';

class ApiException implements Exception {
  ApiException(this.message, {this.statusCode});

  final String message;
  final int? statusCode;

  @override
  String toString() => message;
}

/// Cliente del backend de Pitazo (ver carpeta `worker/`).
class ApiClient {
  ApiClient({http.Client? client, String? baseUrl})
      : _client = client ?? http.Client(),
        _baseUrl = baseUrl ?? AppConfig.apiBaseUrl;

  final http.Client _client;
  final String _baseUrl;

  /// Partidos del día indicado (día local, según [AppConfig.timeZone]).
  Future<List<FootballMatch>> fetchMatches(DateTime day) async {
    final uri = Uri.parse('$_baseUrl/matches').replace(
      queryParameters: {
        'date': DateFormat('yyyy-MM-dd').format(day),
        'tz': AppConfig.timeZone,
      },
    );
    final res = await _client.get(uri).timeout(const Duration(seconds: 15));
    if (res.statusCode != 200) {
      throw ApiException(
        'El servidor respondió con el código ${res.statusCode}',
        statusCode: res.statusCode,
      );
    }
    final body = jsonDecode(utf8.decode(res.bodyBytes)) as Map<String, dynamic>;
    final list = (body['matches'] as List<dynamic>?) ?? const <dynamic>[];
    return list
        .map((e) => FootballMatch.fromJson(e as Map<String, dynamic>))
        .toList();
  }
}
