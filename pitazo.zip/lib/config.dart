/// Ajustes de la app.
///
/// La dirección del backend se pasa al compilar, sin tocar el código:
///   flutter run --dart-define=API_BASE_URL=https://pitazo-api.TU-USUARIO.workers.dev
class AppConfig {
  AppConfig._();

  static const String apiBaseUrl = String.fromEnvironment(
    'API_BASE_URL',
    defaultValue: 'https://pitazo-api.example.workers.dev',
  );

  /// Zona horaria con la que el backend decide qué partidos son "de hoy".
  static const String timeZone = 'Europe/Madrid';

  /// Cada cuánto se refresca el día actual.
  static const Duration refreshEvery = Duration(seconds: 60);
}
