# Pitazo

App Android de resultados de fútbol (Flutter) con diseño editorial. Los datos
vienen de [football-data.org](https://www.football-data.org) a través de un
backend propio y gratuito en Cloudflare Workers.

```
app Flutter  →  backend (Cloudflare Worker, con caché)  →  football-data.org
```

Todo se puede montar y actualizar desde el móvil: GitHub compila el APK y lo
publica en **Releases**.

## Puesta en marcha desde el móvil

### 1. Cuentas gratuitas necesarias

- **football-data.org**: regístrate en football-data.org/client/register. La
  clave llega por correo.
- **Cloudflare**: crea una cuenta gratuita. Entra una vez en *Workers y Pages*
  para que te asigne tu dirección `workers.dev`.
  - *Account ID*: aparece en la página principal de tu cuenta.
  - *API token*: Mi perfil → Tokens de API → Crear token → plantilla
    **Edit Cloudflare Workers**.

### 2. Secretos en GitHub

En el repositorio: **Settings → Secrets and variables → Actions → New
repository secret**. Crea estos tres:

| Nombre | Valor |
| --- | --- |
| `FOOTBALL_DATA_KEY` | la clave de football-data.org |
| `CLOUDFLARE_API_TOKEN` | el token de Cloudflare |
| `CLOUDFLARE_ACCOUNT_ID` | el Account ID de Cloudflare |

Los secretos no se muestran después de guardarlos y no aparecen en el código.

### 3. Publicar el backend

**Actions → Publicar backend → Run workflow.** Al terminar, abre la ejecución:
en el resumen aparece la dirección del backend
(`https://pitazo-api.TU-USUARIO.workers.dev`). Comprueba que funciona abriendo
esa dirección seguida de `/matches?date=2026-11-09` en el navegador.

### 4. Indicar la dirección a la app

**Settings → Secrets and variables → Actions → pestaña Variables → New
repository variable:**

| Nombre | Valor |
| --- | --- |
| `API_BASE_URL` | la dirección del paso anterior, sin barra final |

### 5. Compilar e instalar el APK

1. **Actions → Compilar APK → Run workflow** (tarda unos minutos).
2. Abre la pestaña **Releases** del repositorio y toca el archivo
   `app-release.apk` de la última compilación.
3. Android pedirá permiso para instalar apps desde el navegador o desde GitHub
   (*Instalar apps desconocidas*). Acéptalo e instala.

Las compilaciones siguientes se instalan encima de la anterior sin desinstalar.
Para obtener un APK nuevo, vuelve a ejecutar *Compilar APK* a mano.

### Subir el proyecto como un único zip (desde el móvil)

El navegador del móvil no puede subir carpetas a GitHub. Alternativa: crea a
mano en GitHub solo los dos archivos de `.github/workflows/` y sube
`pitazo.zip` a la raíz del repositorio. Los flujos descomprimen el zip al
ejecutarse. Para actualizar la app, sube un `pitazo.zip` nuevo con el mismo
nombre y vuelve a ejecutar el flujo.

## Estructura

```
lib/                  App Flutter (modelos, cliente HTTP, pantallas, tema)
test/                 Pruebas de la app
worker/               Backend (Cloudflare Worker) y su prueba sin red
keystore/             Clave de firma de desarrollo (ver nota)
.github/workflows/    Compilación del APK y publicación del backend
```

## Estado actual

- Hecho: pantalla **Partidos** con tira de días, partidos agrupados por liga,
  refresco cada 60 s en el día actual y actualización al tirar hacia abajo.
- Pendiente: Tablas, Favoritos, Ajustes, notificaciones de goles.
- En el plan gratuito de football-data.org los marcadores llevan retraso y
  solo hay 12 competiciones.

## Desarrollo en un ordenador (opcional)

```bash
# Backend
cd worker && node test/smoke.mjs

# App (necesita Flutter instalado)
flutter create --platforms=android --org com.pitazo --project-name pitazo .
# Añade <uses-permission android:name="android.permission.INTERNET"/> dentro de
# <manifest> en android/app/src/main/AndroidManifest.xml
flutter pub get
flutter run --dart-define=API_BASE_URL=https://pitazo-api.TU-USUARIO.workers.dev
```

## Nota sobre la firma

El APK se firma con `keystore/debug.keystore`, una clave de desarrollo pública
que solo sirve para instalar la app en tu móvil. **No vale para Google Play**:
para publicar allí hará falta una clave de subida propia y privada.
