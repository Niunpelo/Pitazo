// Pitazo API: proxy con caché delante de football-data.org (plan gratuito).
//
// Por qué existe:
//  - La clave de la API queda en el servidor y no dentro del APK.
//  - El plan gratuito permite 10 peticiones por minuto en total; con caché,
//    todos los usuarios comparten las mismas respuestas.
//  - Devuelve un JSON pequeño y estable, así la app no depende del formato
//    de ningún proveedor (se puede cambiar de proveedor sin tocar la app).

const UPSTREAM = 'https://api.football-data.org/v4';
const DEFAULT_TZ = 'Europe/Madrid';
const MATCHES_TTL_MS = 60_000;
const STANDINGS_TTL_MS = 10 * 60_000;
const MAX_CACHE_ENTRIES = 200;

// Orden en que se muestran las competiciones (las desconocidas, al final).
const LEAGUE_PRIORITY = ['PD', 'CL', 'PL', 'SA', 'BL1', 'FL1', 'PPL', 'DED', 'ELC', 'BSA', 'WC', 'EC'];

const AREA_ES = {
  Spain: 'España',
  England: 'Inglaterra',
  Germany: 'Alemania',
  Italy: 'Italia',
  France: 'Francia',
  Netherlands: 'Países Bajos',
  Portugal: 'Portugal',
  Brazil: 'Brasil',
  Europe: 'Europa',
  World: 'Mundo',
};

// Caché en memoria del Worker (por instancia). Si una instancia se reinicia,
// simplemente se vuelve a pedir el dato.
const cache = new Map();

class HttpError extends Error {
  constructor(status, code) {
    super(code);
    this.status = status;
    this.code = code;
  }
}

export default {
  async fetch(request, env) {
    if (request.method === 'OPTIONS') return withCors(new Response(null, { status: 204 }));
    if (request.method !== 'GET') return withCors(json({ error: 'method_not_allowed' }, 405));

    const url = new URL(request.url);
    try {
      switch (url.pathname) {
        case '/':
          return withCors(json({ ok: true, service: 'pitazo-api' }));
        case '/matches':
          return withCors(await handleMatches(url, env));
        case '/standings':
          return withCors(await handleStandings(url, env));
        default:
          return withCors(json({ error: 'not_found' }, 404));
      }
    } catch (err) {
      if (err instanceof HttpError) return withCors(json({ error: err.code }, err.status));
      return withCors(json({ error: 'internal_error' }, 500));
    }
  },
};

// GET /matches?date=YYYY-MM-DD&tz=Europe/Madrid
async function handleMatches(url, env) {
  const date = url.searchParams.get('date');
  const tz = url.searchParams.get('tz') || DEFAULT_TZ;
  if (!isValidDate(date)) throw new HttpError(400, 'invalid_date');
  if (!isValidTimeZone(tz)) throw new HttpError(400, 'invalid_tz');

  const ttl = numberOr(env.MATCHES_TTL_MS, MATCHES_TTL_MS);
  const data = await cached(`matches:${date}:${tz}`, ttl, async () => {
    // football-data.org filtra por fecha UTC. Se pide un margen de días y se
    // filtra aquí por el día local del usuario.
    const from = addDays(date, -1);
    const to = addDays(date, 2);
    const raw = await upstream(`/matches?dateFrom=${from}&dateTo=${to}`, env);
    const matches = (raw.matches || [])
      .filter((m) => localDate(m.utcDate, tz) === date)
      .map(normalizeMatch)
      .sort(byLeagueThenKickoff);
    return { date, tz, generatedAt: new Date().toISOString(), matches };
  });
  return json(data);
}

// GET /standings?competition=PD
async function handleStandings(url, env) {
  const code = url.searchParams.get('competition');
  if (!code || !/^[A-Z0-9]{2,5}$/.test(code)) throw new HttpError(400, 'invalid_competition');

  const ttl = numberOr(env.STANDINGS_TTL_MS, STANDINGS_TTL_MS);
  const data = await cached(`standings:${code}`, ttl, async () => {
    const raw = await upstream(`/competitions/${code}/standings`, env);
    const standings = raw.standings || [];
    const total = standings.find((s) => s.type === 'TOTAL') || standings[0];
    const table = ((total && total.table) || []).map((r) => ({
      position: r.position,
      team: normalizeTeam(r.team),
      played: r.playedGames,
      won: r.won,
      draw: r.draw,
      lost: r.lost,
      points: r.points,
      goalsFor: r.goalsFor,
      goalsAgainst: r.goalsAgainst,
      goalDifference: r.goalDifference,
    }));
    return {
      competition: { code: raw.competition?.code ?? code, name: raw.competition?.name ?? code },
      season: raw.season?.startDate ? raw.season.startDate.slice(0, 4) : null,
      generatedAt: new Date().toISOString(),
      table,
    };
  });
  return json(data);
}

// ---------- football-data.org ----------

async function upstream(path, env) {
  if (!env.FOOTBALL_DATA_KEY) throw new HttpError(500, 'missing_api_key');
  let res;
  try {
    res = await fetch(UPSTREAM + path, { headers: { 'X-Auth-Token': env.FOOTBALL_DATA_KEY } });
  } catch {
    throw new HttpError(502, 'upstream_unreachable');
  }
  if (res.status === 429) throw new HttpError(503, 'rate_limited');
  if (res.status === 403 || res.status === 404) throw new HttpError(res.status, 'not_available');
  if (!res.ok) throw new HttpError(502, 'upstream_error');
  return res.json();
}

function normalizeTeam(t) {
  const team = t || {};
  const name = team.name || '—';
  return {
    id: team.id ?? null,
    name,
    shortName: team.shortName || name,
    tla: team.tla ?? null,
    crest: team.crest ?? null,
  };
}

function normalizeMatch(m) {
  const areaName = m.area?.name ?? m.competition?.area?.name ?? null;
  return {
    id: m.id,
    utcDate: m.utcDate,
    status: m.status,
    minute: typeof m.minute === 'number' ? m.minute : null,
    competition: {
      code: m.competition?.code ?? 'OTHER',
      name: m.competition?.name ?? 'Otras competiciones',
      area: AREA_ES[areaName] ?? areaName,
    },
    home: normalizeTeam(m.homeTeam),
    away: normalizeTeam(m.awayTeam),
    score: {
      home: m.score?.fullTime?.home ?? null,
      away: m.score?.fullTime?.away ?? null,
    },
  };
}

function leagueRank(code) {
  const i = LEAGUE_PRIORITY.indexOf(code);
  return i === -1 ? LEAGUE_PRIORITY.length : i;
}

function byLeagueThenKickoff(a, b) {
  const byRank = leagueRank(a.competition.code) - leagueRank(b.competition.code);
  if (byRank !== 0) return byRank;
  const byName = a.competition.name.localeCompare(b.competition.name);
  if (byName !== 0) return byName;
  return a.utcDate < b.utcDate ? -1 : a.utcDate > b.utcDate ? 1 : 0;
}

// ---------- utilidades ----------

async function cached(key, ttlMs, load) {
  const hit = cache.get(key);
  const now = Date.now();
  if (hit && now - hit.at < ttlMs) return hit.value;
  try {
    const value = await load();
    cache.set(key, { at: now, value });
    prune();
    return value;
  } catch (err) {
    // Si el proveedor falla o limita, se sirve el último dato bueno.
    if (hit) return hit.value;
    throw err;
  }
}

function prune() {
  while (cache.size > MAX_CACHE_ENTRIES) {
    cache.delete(cache.keys().next().value);
  }
}

function numberOr(value, fallback) {
  if (value === undefined || value === null || value === '') return fallback;
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
}

function isValidDate(s) {
  if (typeof s !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(s)) return false;
  const d = new Date(`${s}T00:00:00Z`);
  return !Number.isNaN(d.getTime()) && d.toISOString().slice(0, 10) === s;
}

function addDays(s, n) {
  const [y, m, d] = s.split('-').map(Number);
  return new Date(Date.UTC(y, m - 1, d + n)).toISOString().slice(0, 10);
}

function isValidTimeZone(tz) {
  try {
    new Intl.DateTimeFormat('en-US', { timeZone: tz });
    return true;
  } catch {
    return false;
  }
}

function localDate(iso, tz) {
  const parts = new Intl.DateTimeFormat('en-US', {
    timeZone: tz,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).formatToParts(new Date(iso));
  const get = (type) => parts.find((p) => p.type === type).value;
  return `${get('year')}-${get('month')}-${get('day')}`;
}

function json(body, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: {
      'content-type': 'application/json; charset=utf-8',
      'cache-control': status === 200 ? 'public, max-age=30' : 'no-store',
    },
  });
}

function withCors(res) {
  res.headers.set('Access-Control-Allow-Origin', '*');
  res.headers.set('Access-Control-Allow-Methods', 'GET, OPTIONS');
  return res;
}
