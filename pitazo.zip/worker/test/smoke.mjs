// Prueba rápida sin red: se simula football-data.org con datos de ejemplo.
// Ejecutar con: node test/smoke.mjs
import assert from 'node:assert/strict';
import worker from '../src/index.js';

const MATCHES = {
  matches: [
    {
      id: 1,
      utcDate: '2026-11-09T20:00:00Z',
      status: 'IN_PLAY',
      minute: 67,
      area: { name: 'Spain' },
      competition: { code: 'PD', name: 'Primera Division' },
      homeTeam: { id: 81, name: 'FC Barcelona', shortName: 'Barça', tla: 'FCB', crest: 'https://example.com/fcb.png' },
      awayTeam: { id: 95, name: 'Valencia CF', shortName: 'Valencia', tla: 'VAL', crest: null },
      score: { fullTime: { home: 1, away: 1 } },
    },
    {
      // 23:30 UTC del día 8 = 00:30 del día 9 en Madrid: debe entrar.
      id: 2,
      utcDate: '2026-11-08T23:30:00Z',
      status: 'FINISHED',
      area: { name: 'England' },
      competition: { code: 'PL', name: 'Premier League' },
      homeTeam: { id: 1, name: 'Tottenham Hotspur FC', shortName: 'Tottenham', tla: 'TOT' },
      awayTeam: { id: 2, name: 'Newcastle United FC', shortName: 'Newcastle', tla: 'NEW' },
      score: { fullTime: { home: 3, away: 2 } },
    },
    {
      // 23:30 UTC del día 9 = 00:30 del día 10 en Madrid: no debe entrar.
      id: 3,
      utcDate: '2026-11-09T23:30:00Z',
      status: 'SCHEDULED',
      competition: { code: 'PL', name: 'Premier League' },
      homeTeam: { id: 3, name: 'A' },
      awayTeam: { id: 4, name: 'B' },
      score: { fullTime: { home: null, away: null } },
    },
    {
      // Día 8 en Madrid: no debe entrar.
      id: 4,
      utcDate: '2026-11-08T20:00:00Z',
      status: 'FINISHED',
      competition: { code: 'PL', name: 'Premier League' },
      homeTeam: { id: 5, name: 'C' },
      awayTeam: { id: 6, name: 'D' },
      score: { fullTime: { home: 0, away: 0 } },
    },
    {
      id: 5,
      utcDate: '2026-11-09T19:45:00Z',
      status: 'TIMED',
      area: { name: 'England' },
      competition: { code: 'PL', name: 'Premier League' },
      homeTeam: { id: 65, name: 'Manchester City FC', shortName: 'Man City', tla: 'MCI' },
      awayTeam: { id: 64, name: 'Liverpool FC', shortName: 'Liverpool', tla: 'LIV' },
      score: { fullTime: { home: null, away: null } },
    },
  ],
};

const STANDINGS = {
  competition: { code: 'PD', name: 'Primera Division' },
  season: { startDate: '2026-08-15' },
  standings: [
    {
      type: 'TOTAL',
      table: [
        {
          position: 1,
          team: { id: 86, name: 'Real Madrid CF', shortName: 'Real Madrid', tla: 'RMA' },
          playedGames: 11,
          won: 9,
          draw: 1,
          lost: 1,
          points: 28,
          goalsFor: 25,
          goalsAgainst: 9,
          goalDifference: 16,
        },
      ],
    },
  ],
};

const calls = [];
let mode = 'ok';
globalThis.fetch = async (url, init) => {
  calls.push({ url: String(url), headers: init?.headers });
  if (mode === 'rate') return new Response('{}', { status: 429 });
  if (String(url).includes('/standings')) return Response.json(STANDINGS);
  return Response.json(MATCHES);
};

const env = { FOOTBALL_DATA_KEY: 'test-key' };
const get = (path, e = env) => worker.fetch(new Request(`https://pitazo.test${path}`), e);

// 1. Partidos del día: filtro por zona horaria, orden y formato.
let res = await get('/matches?date=2026-11-09&tz=Europe/Madrid');
assert.equal(res.status, 200);
let body = await res.json();
assert.deepEqual(body.matches.map((m) => m.id), [1, 2, 5]);
assert.equal(body.matches[0].competition.area, 'España');
assert.equal(body.matches[0].minute, 67);
assert.equal(body.matches[0].home.shortName, 'Barça');
assert.equal(body.matches[0].score.home, 1);
assert.equal(body.matches[2].score.home, null);
assert.equal(body.matches[1].home.crest, null);
assert.ok(calls[0].url.includes('dateFrom=2026-11-08&dateTo=2026-11-11'));
assert.equal(calls[0].headers['X-Auth-Token'], 'test-key');

// 2. Segunda petición idéntica: sale de la caché.
await get('/matches?date=2026-11-09&tz=Europe/Madrid');
assert.equal(calls.length, 1);

// 3. Si el proveedor limita (429) y hay un dato anterior, se sirve ese.
mode = 'rate';
res = await get('/matches?date=2026-11-09&tz=Europe/Madrid', { ...env, MATCHES_TTL_MS: '0' });
assert.equal(res.status, 200);

// 4. Sin dato anterior y con 429, el error es 503.
res = await get('/matches?date=2026-12-01');
assert.equal(res.status, 503);
assert.equal((await res.json()).error, 'rate_limited');
mode = 'ok';

// 5. Validaciones.
assert.equal((await get('/matches?date=2026-13-45')).status, 400);
assert.equal((await get('/matches')).status, 400);
assert.equal((await get('/matches?date=2026-11-09&tz=Mars/Base')).status, 400);
assert.equal((await get('/standings?competition=pd;drop')).status, 400);
assert.equal((await get('/matches?date=2027-01-01', {})).status, 500);

// 6. Clasificación.
res = await get('/standings?competition=PD');
body = await res.json();
assert.equal(res.status, 200);
assert.equal(body.competition.code, 'PD');
assert.equal(body.season, '2026');
assert.equal(body.table[0].team.shortName, 'Real Madrid');
assert.equal(body.table[0].points, 28);

// 7. Rutas desconocidas y CORS.
assert.equal((await get('/nada')).status, 404);
res = await get('/');
assert.equal(res.headers.get('access-control-allow-origin'), '*');

console.log('OK: todas las comprobaciones del Worker han pasado.');
