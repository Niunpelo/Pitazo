enum MatchPhase { scheduled, live, halfTime, finished, interrupted }

class Team {
  const Team({
    required this.name,
    required this.shortName,
    this.id,
    this.tla,
    this.crest,
  });

  final int? id;
  final String name;
  final String shortName;
  final String? tla;
  final String? crest;

  factory Team.fromJson(Map<String, dynamic> json) {
    final name = (json['name'] as String?) ?? '—';
    return Team(
      id: (json['id'] as num?)?.toInt(),
      name: name,
      shortName: (json['shortName'] as String?) ?? name,
      tla: json['tla'] as String?,
      crest: json['crest'] as String?,
    );
  }
}

class FootballMatch {
  const FootballMatch({
    required this.id,
    required this.kickoff,
    required this.status,
    required this.competitionCode,
    required this.competitionName,
    required this.home,
    required this.away,
    this.minute,
    this.area,
    this.homeGoals,
    this.awayGoals,
  });

  final int id;

  /// Hora de inicio en UTC. Para mostrarla, usar `kickoff.toLocal()`.
  final DateTime kickoff;
  final String status;
  final int? minute;
  final String competitionCode;
  final String competitionName;
  final String? area;
  final Team home;
  final Team away;
  final int? homeGoals;
  final int? awayGoals;

  factory FootballMatch.fromJson(Map<String, dynamic> json) {
    final competition =
        (json['competition'] as Map<String, dynamic>?) ?? const <String, dynamic>{};
    final score = (json['score'] as Map<String, dynamic>?) ?? const <String, dynamic>{};
    return FootballMatch(
      id: (json['id'] as num).toInt(),
      kickoff: DateTime.parse(json['utcDate'] as String),
      status: (json['status'] as String?) ?? 'SCHEDULED',
      minute: (json['minute'] as num?)?.toInt(),
      competitionCode: (competition['code'] as String?) ?? 'OTHER',
      competitionName: (competition['name'] as String?) ?? 'Otras competiciones',
      area: competition['area'] as String?,
      home: Team.fromJson(
        (json['home'] as Map<String, dynamic>?) ?? const <String, dynamic>{},
      ),
      away: Team.fromJson(
        (json['away'] as Map<String, dynamic>?) ?? const <String, dynamic>{},
      ),
      homeGoals: (score['home'] as num?)?.toInt(),
      awayGoals: (score['away'] as num?)?.toInt(),
    );
  }

  MatchPhase get phase {
    switch (status) {
      case 'IN_PLAY':
        return MatchPhase.live;
      case 'PAUSED':
        return MatchPhase.halfTime;
      case 'FINISHED':
      case 'AWARDED':
        return MatchPhase.finished;
      case 'POSTPONED':
      case 'SUSPENDED':
      case 'CANCELLED':
        return MatchPhase.interrupted;
      default:
        return MatchPhase.scheduled;
    }
  }

  bool get isLive => phase == MatchPhase.live || phase == MatchPhase.halfTime;

  String get interruptedLabel {
    switch (status) {
      case 'POSTPONED':
        return 'Aplazado';
      case 'SUSPENDED':
        return 'Suspendido';
      case 'CANCELLED':
        return 'Cancelado';
      default:
        return status;
    }
  }
}
