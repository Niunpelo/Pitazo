import 'package:flutter_test/flutter_test.dart';
import 'package:pitazo/models/football_match.dart';

void main() {
  test('lee un partido en juego con el formato del backend', () {
    final match = FootballMatch.fromJson({
      'id': 1,
      'utcDate': '2026-11-09T20:00:00Z',
      'status': 'IN_PLAY',
      'minute': 67,
      'competition': {'code': 'PD', 'name': 'Primera Division', 'area': 'España'},
      'home': {'id': 81, 'name': 'FC Barcelona', 'shortName': 'Barça', 'tla': 'FCB'},
      'away': {'id': 95, 'name': 'Valencia CF', 'shortName': 'Valencia'},
      'score': {'home': 1, 'away': 1},
    });

    expect(match.phase, MatchPhase.live);
    expect(match.isLive, isTrue);
    expect(match.minute, 67);
    expect(match.home.shortName, 'Barça');
    expect(match.homeGoals, 1);
    expect(match.kickoff.isUtc, isTrue);
  });

  test('un partido sin marcador ni minuto queda como programado', () {
    final match = FootballMatch.fromJson({
      'id': 2,
      'utcDate': '2026-11-09T19:45:00Z',
      'status': 'TIMED',
      'minute': null,
      'competition': {'code': 'PL', 'name': 'Premier League', 'area': 'Inglaterra'},
      'home': {'name': 'Manchester City FC'},
      'away': {'name': 'Liverpool FC'},
      'score': {'home': null, 'away': null},
    });

    expect(match.phase, MatchPhase.scheduled);
    expect(match.homeGoals, isNull);
    expect(match.home.shortName, 'Manchester City FC');
  });

  test('los estados aplazado y suspendido se muestran en español', () {
    FootballMatch withStatus(String status) => FootballMatch.fromJson({
          'id': 3,
          'utcDate': '2026-11-09T19:45:00Z',
          'status': status,
          'competition': {'code': 'PL', 'name': 'Premier League'},
          'home': {'name': 'A'},
          'away': {'name': 'B'},
          'score': {},
        });

    expect(withStatus('POSTPONED').interruptedLabel, 'Aplazado');
    expect(withStatus('SUSPENDED').phase, MatchPhase.interrupted);
    expect(withStatus('FINISHED').phase, MatchPhase.finished);
    expect(withStatus('PAUSED').phase, MatchPhase.halfTime);
  });
}
